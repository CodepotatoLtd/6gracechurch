## 10.1.1: March 9th, 2022

* [Release notes](https://github.com/roots/sage/releases/tag/v10.1.1)
* [Full changelog](https://github.com/roots/sage/compare/v10.0.0...v10.1.1)

## 10.1.0: March 8th, 2022

* [Release notes](https://github.com/roots/sage/releases/tag/v10.1.0)
* [Full changelog](https://github.com/roots/sage/compare/v10.0.0...v10.1.0)

## 10.0.0: March 1st, 2022

* [Release notes](https://github.com/roots/sage/releases/tag/v10.0.0)
* [Full changelog](https://github.com/roots/sage/compare/10.0.0-beta.3...v10.0.0)

## 10.0.0-beta.3: February 14th, 2022

* [Release notes](https://github.com/roots/sage/releases/tag/10.0.0-beta.3)
* [Full changelog](https://github.com/roots/sage/compare/10.0.0-beta.2...10.0.0-beta.3)

## 10.0.0-beta.2: December 21st, 2021

* [Release notes](https://github.com/roots/sage/releases/tag/10.0.0-beta.2)
* [Full changelog](https://github.com/roots/sage/compare/10.0.0-beta.1...10.0.0-beta.2)

## 10.0.0-beta.1: October 21st, 2021

* [Release notes](https://github.com/roots/sage/releases/tag/10.0.0-beta.1)
* [Full changelog](https://github.com/roots/sage/compare/9.0.9...10.0.0-beta.1)
