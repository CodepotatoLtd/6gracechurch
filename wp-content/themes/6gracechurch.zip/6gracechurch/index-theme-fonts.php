<style>
  :root {

    /* fonts */

    --font-headings: <?php echo $options["fonts_headings"];?>  !important;
    --font-copy: <?php echo $options["fonts_copy"];?>  !important;
    --font-nav: <?php echo $options["fonts_nav"];?>  !important;
    --font-buttons: <?php echo $options["fonts_buttons"];?>  !important;
    --font-quotes: <?php echo $options["fonts_quotes"];?>  !important;
    --font-cite: <?php echo $options["fonts_cite"];?>  !important;

  }
</style>
